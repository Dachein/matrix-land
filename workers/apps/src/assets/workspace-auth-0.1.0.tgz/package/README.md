# Fargo Auth SDK

Focused runtime SDK for services that integrate with `workers/auth-worker`.

## Official App Package

The supported package name is `@fargo/auth`. When working through Fargo AI
MCP, call `lego_get_auth_sdk({ appId })` first. It returns the current versioned
package URL, an exact `npm install` command, the required secret names, and an
app-specific Worker example. Do not guess a registry package name or copy an
Auth flow from another App.

The package is distributed from the Fargo LEGO service as a versioned tarball
so internal App builds do not depend on a public npm registry. Bundle the
dependency into the Worker or Pages Function without minification before
calling `lego_worker_deploy` or `lego_pages_deploy`.

The legacy `sdk/fargo-sdk.ts` has been deleted. It mixed Portal catalog, current
user, direct-jump, MCP token, and audit responsibilities. This SDK only covers
Auth Worker runtime auth.

## Browser App Login

Use `FargoBrowserAppSession` for browser-facing Apps. It owns the required
state Cookie, one-time-code exchange, App Basic authentication, redirect
binding, and signed App-local Session Cookie.

1. Give every App an independent HTTPS origin.
2. Configure two independent deployment secrets:
   `FARGO_AUTH_APP_SECRET` and `FARGO_APP_SESSION_SECRET`.
3. Route login start, callback, session read, and logout through the helper.
4. Treat the returned `session.user` as the only browser user identity.
5. Never read `x-fargo-*` or `cf-access-*` request Headers as App identity.
6. Configure the browser-facing Fargo SSO origin explicitly. It may differ
   from the server-only Auth API/issuer origin.

The App backend does not use `AUTH_SERVICE_TOKEN`, does not trust browser-sent
profile data, and does not call lego-worker for user identity.

The SDK always sends HTTP Basic client authentication to Auth Worker. Both
secrets must be at least 32 characters and are deployed to only that App
runtime. The default local Session TTL is 15 minutes so centralized permission
changes have a bounded propagation delay; privileged actions should use a
shorter or online authorization check.

Basic implementation:

```ts
const auth = new FargoBrowserAppSession({
  appId: "app-ops",
  appOrigin: "https://ops.example.com",
  appSecret: process.env.FARGO_AUTH_APP_SECRET,
  appVersion: process.env.APP_VERSION,
  authOrigin: "https://auth-api.example.com",
  authorizeOrigin: process.env.FARGO_AUTH_AUTHORIZE_ORIGIN,
  authorizePath: "/auth/v1/authorize",
  sessionSecret: process.env.FARGO_APP_SESSION_SECRET
});

if (url.pathname === "/auth/fargo/start") return auth.start(request);
if (url.pathname === "/auth/fargo/callback") return auth.callback(request);
if (url.pathname === "/auth/fargo/logout") return auth.logout();
// Serve /auth/fargo/signed-out without automatically starting SSO again.
const session = await auth.require(request);
```

App logout clears only the App Session and pending state, then redirects to
`/auth/fargo/signed-out`. That public landing page should offer an explicit
"sign in again" action. Global Fargo logout is a separate product action that
clears the central SSO session.

`FargoAuthServer` remains the lower-level server exchange client for existing
integrations. New browser Apps should use `FargoBrowserAppSession`. Legacy
`fargo_token` callbacks are migration input only and must restart the standard
code flow; they must never create an App Session directly.

## Resource API Protection

Use `FargoAuthResource` in an API route or middleware.

1. Configure the SDK with `authOrigin`, optional `introspectionToken`, and an
   optional custom `introspectionPath`.
2. Call `requireAccess(request, { audience, scopes })`.
3. The SDK reads `Authorization: Bearer ...`, introspects the token, normalizes
   claims, then checks audience and required scopes.

Resource APIs validate caller tokens. They do not launch users, create App
clients, sync grants, or issue Portal direct-jump credentials.

For API-backed Skills, Fargo MCP acts as the broker: it asks Auth Worker to mint
a short-lived `resource_access` token for the current Fargo user, calls the
Resource API with that token, and never returns the token to the Agent or LLM.
The Resource API still verifies the request with this SDK.

Basic implementation:

```ts
const auth = new FargoAuthResource({
  authOrigin: "https://auth.example.com",
  introspectionToken: process.env.FARGO_AUTH_INTROSPECTION_TOKEN
});

const claims = await auth.requireAccess(request, {
  audience: "https://api.ops.example.com",
  scopes: ["orders:read"]
});

// Use claims.sub as the Fargo user id for authorization and audit.
```

## Ownership Boundary

- Portal/Pages and lego-worker register confidential clients, callback
  allowlists, access policy, and grants through Auth Worker admin/runtime APIs.
- Auth Worker owns token issuance, verification, introspection, session/grant
  state, and audit.
- App backends and Resource APIs use this SDK only to consume Auth Worker
  runtime auth results.
